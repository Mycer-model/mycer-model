# MYCER Model

MYCER (Multi-indicator Composite Energy Readiness) is a multi-layered decision-support model based on AHP and regression-based projections to assess energy systems.

## Contents

- 🔢 AHP matrix builder and scorer
- 📈 SEY (System Energy Yield) regression notebook
- 📁 Raw data files (e.g. UCSD, Gebze OSB)

## License
MIT License
