import numpy as np
import pandas as pd

def calculate_weights(matrix):
    eigvals, eigvecs = np.linalg.eig(matrix)
    max_index = np.argmax(eigvals)
    weights = np.real(eigvecs[:, max_index])
    weights = weights / weights.sum()
    return weights

def calculate_cr(matrix):
    n = matrix.shape[0]
    eigvals, _ = np.linalg.eig(matrix)
    lambda_max = np.max(np.real(eigvals))
    ci = (lambda_max - n) / (n - 1)
    ri_values = {1: 0.00, 2: 0.00, 3: 0.58, 4: 0.90, 5: 1.12}
    ri = ri_values.get(n, 1.12)
    cr = ci / ri
    return cr
